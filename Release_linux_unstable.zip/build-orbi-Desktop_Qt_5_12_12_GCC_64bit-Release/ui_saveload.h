/********************************************************************************
** Form generated from reading UI file 'saveload.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SAVELOAD_H
#define UI_SAVELOAD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_SaveLoad
{
public:
    QTextEdit *Text;
    QPushButton *Save;
    QPushButton *Load;
    QLabel *label;

    void setupUi(QDialog *SaveLoad)
    {
        if (SaveLoad->objectName().isEmpty())
            SaveLoad->setObjectName(QString::fromUtf8("SaveLoad"));
        SaveLoad->resize(317, 107);
#ifndef QT_NO_WHATSTHIS
        SaveLoad->setWhatsThis(QString::fromUtf8(""));
#endif // QT_NO_WHATSTHIS
        Text = new QTextEdit(SaveLoad);
        Text->setObjectName(QString::fromUtf8("Text"));
        Text->setGeometry(QRect(30, 30, 221, 31));
        Save = new QPushButton(SaveLoad);
        Save->setObjectName(QString::fromUtf8("Save"));
        Save->setGeometry(QRect(40, 80, 80, 21));
        Load = new QPushButton(SaveLoad);
        Load->setObjectName(QString::fromUtf8("Load"));
        Load->setGeometry(QRect(210, 80, 80, 21));
        label = new QLabel(SaveLoad);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(260, 30, 47, 31));

        retranslateUi(SaveLoad);

        QMetaObject::connectSlotsByName(SaveLoad);
    } // setupUi

    void retranslateUi(QDialog *SaveLoad)
    {
        SaveLoad->setWindowTitle(QApplication::translate("SaveLoad", "Dialog", nullptr));
        Save->setText(QApplication::translate("SaveLoad", "Save", nullptr));
        Load->setText(QApplication::translate("SaveLoad", "Load", nullptr));
        label->setText(QApplication::translate("SaveLoad", ".txt", nullptr));
    } // retranslateUi

};

namespace Ui {
    class SaveLoad: public Ui_SaveLoad {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SAVELOAD_H
