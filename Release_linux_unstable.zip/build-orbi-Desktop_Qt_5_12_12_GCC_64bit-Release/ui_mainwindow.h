/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *earthmooon;
    QAction *actionBinary;
    QAction *actionBinary_Binary;
    QAction *actionRings;
    QAction *actionInner_Solar_System;
    QAction *actionRandom;
    QAction *actionRandom_Twist;
    QAction *Specialrel;
    QAction *Spawn_rocket;
    QAction *actionset_Speed_of_Light;
    QAction *Collision;
    QAction *actionEnable_Debris;
    QAction *actionSmash;
    QAction *actionTransfer;
    QAction *actionPrecession;
    QAction *actionLoad_Save;
    QAction *actionEnable;
    QAction *actionVolume;
    QAction *actionPerformance_Test;
    QAction *actionShow_Visualization;
    QAction *Barnes_Hut;
    QAction *actionInter_planetary;
    QWidget *centralwidget;
    QVBoxLayout *verticalLayout;
    QVBoxLayout *Verticallayout;
    QGraphicsView *Gameview;
    QGridLayout *gridLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QCheckBox *Traced;
    QSlider *MassSlider;
    QCheckBox *checkBox;
    QSlider *GSlider;
    QSlider *TimeSlider;
    QPushButton *pushButton;
    QPushButton *Refresh;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuSystems;
    QMenu *menuCollisions;
    QMenu *menuMusic;
    QMenu *menuMethod;
    QMenu *menuBarnes_Hut;
    QMenu *menuRocket;
    QMenu *menuSelect_Program;
    QMenu *menuRElativite;
    QMenu *menuSystems_2;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1443, 806);
        QPalette palette;
        QBrush brush(QColor(101, 127, 160, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Mid, brush);
        QBrush brush1(QColor(105, 158, 215, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::Highlight, brush1);
        palette.setBrush(QPalette::Inactive, QPalette::Mid, brush);
        palette.setBrush(QPalette::Inactive, QPalette::Highlight, brush1);
        palette.setBrush(QPalette::Disabled, QPalette::Mid, brush);
        QBrush brush2(QColor(0, 120, 215, 255));
        brush2.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::Highlight, brush2);
        MainWindow->setPalette(palette);
        QFont font;
        font.setFamily(QString::fromUtf8("Yu Gothic UI Semibold"));
        font.setBold(true);
        font.setWeight(75);
        MainWindow->setFont(font);
        earthmooon = new QAction(MainWindow);
        earthmooon->setObjectName(QString::fromUtf8("earthmooon"));
        earthmooon->setCheckable(false);
        earthmooon->setShortcutContext(Qt::WidgetShortcut);
        earthmooon->setMenuRole(QAction::ApplicationSpecificRole);
        actionBinary = new QAction(MainWindow);
        actionBinary->setObjectName(QString::fromUtf8("actionBinary"));
        actionBinary_Binary = new QAction(MainWindow);
        actionBinary_Binary->setObjectName(QString::fromUtf8("actionBinary_Binary"));
        actionRings = new QAction(MainWindow);
        actionRings->setObjectName(QString::fromUtf8("actionRings"));
        actionInner_Solar_System = new QAction(MainWindow);
        actionInner_Solar_System->setObjectName(QString::fromUtf8("actionInner_Solar_System"));
        actionRandom = new QAction(MainWindow);
        actionRandom->setObjectName(QString::fromUtf8("actionRandom"));
        actionRandom_Twist = new QAction(MainWindow);
        actionRandom_Twist->setObjectName(QString::fromUtf8("actionRandom_Twist"));
        Specialrel = new QAction(MainWindow);
        Specialrel->setObjectName(QString::fromUtf8("Specialrel"));
        Specialrel->setCheckable(true);
        Spawn_rocket = new QAction(MainWindow);
        Spawn_rocket->setObjectName(QString::fromUtf8("Spawn_rocket"));
        actionset_Speed_of_Light = new QAction(MainWindow);
        actionset_Speed_of_Light->setObjectName(QString::fromUtf8("actionset_Speed_of_Light"));
        Collision = new QAction(MainWindow);
        Collision->setObjectName(QString::fromUtf8("Collision"));
        Collision->setCheckable(true);
        Collision->setChecked(true);
        actionEnable_Debris = new QAction(MainWindow);
        actionEnable_Debris->setObjectName(QString::fromUtf8("actionEnable_Debris"));
        actionEnable_Debris->setCheckable(true);
        actionEnable_Debris->setChecked(true);
        actionSmash = new QAction(MainWindow);
        actionSmash->setObjectName(QString::fromUtf8("actionSmash"));
        actionTransfer = new QAction(MainWindow);
        actionTransfer->setObjectName(QString::fromUtf8("actionTransfer"));
        actionPrecession = new QAction(MainWindow);
        actionPrecession->setObjectName(QString::fromUtf8("actionPrecession"));
        actionLoad_Save = new QAction(MainWindow);
        actionLoad_Save->setObjectName(QString::fromUtf8("actionLoad_Save"));
        actionEnable = new QAction(MainWindow);
        actionEnable->setObjectName(QString::fromUtf8("actionEnable"));
        actionEnable->setCheckable(true);
        actionEnable->setChecked(true);
        actionVolume = new QAction(MainWindow);
        actionVolume->setObjectName(QString::fromUtf8("actionVolume"));
        actionPerformance_Test = new QAction(MainWindow);
        actionPerformance_Test->setObjectName(QString::fromUtf8("actionPerformance_Test"));
        actionShow_Visualization = new QAction(MainWindow);
        actionShow_Visualization->setObjectName(QString::fromUtf8("actionShow_Visualization"));
        actionShow_Visualization->setCheckable(true);
        Barnes_Hut = new QAction(MainWindow);
        Barnes_Hut->setObjectName(QString::fromUtf8("Barnes_Hut"));
        Barnes_Hut->setCheckable(true);
        Barnes_Hut->setChecked(true);
        actionInter_planetary = new QAction(MainWindow);
        actionInter_planetary->setObjectName(QString::fromUtf8("actionInter_planetary"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        verticalLayout = new QVBoxLayout(centralwidget);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        Verticallayout = new QVBoxLayout();
        Verticallayout->setSpacing(0);
        Verticallayout->setObjectName(QString::fromUtf8("Verticallayout"));
        Verticallayout->setSizeConstraint(QLayout::SetMinimumSize);
        Gameview = new QGraphicsView(centralwidget);
        Gameview->setObjectName(QString::fromUtf8("Gameview"));
        Gameview->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Maximum, QSizePolicy::Maximum);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(1);
        sizePolicy1.setHeightForWidth(Gameview->sizePolicy().hasHeightForWidth());
        Gameview->setSizePolicy(sizePolicy1);
        Gameview->setMinimumSize(QSize(1425, 700));
        Gameview->setMaximumSize(QSize(60000, 60000));
        Gameview->setSizeIncrement(QSize(1, 1));
        Gameview->setBaseSize(QSize(1, 1));
        Gameview->viewport()->setProperty("cursor", QVariant(QCursor(Qt::CrossCursor)));
        Gameview->setMouseTracking(true);
        Gameview->setTabletTracking(false);
        Gameview->setFocusPolicy(Qt::NoFocus);
        Gameview->setContextMenuPolicy(Qt::DefaultContextMenu);
        Gameview->setAcceptDrops(true);
#ifndef QT_NO_WHATSTHIS
        Gameview->setWhatsThis(QString::fromUtf8(""));
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        Gameview->setAccessibleName(QString::fromUtf8(""));
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        Gameview->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_NO_ACCESSIBILITY
        Gameview->setLayoutDirection(Qt::LeftToRight);
        Gameview->setAutoFillBackground(true);
        Gameview->setStyleSheet(QString::fromUtf8("background-color: rgb(10, 16, 16);"));
        Gameview->setFrameShape(QFrame::StyledPanel);
        Gameview->setFrameShadow(QFrame::Sunken);
        Gameview->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        Gameview->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        Gameview->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        QBrush brush3(QColor(141, 144, 137, 255));
        brush3.setStyle(Qt::NoBrush);
        Gameview->setBackgroundBrush(brush3);
        QBrush brush4(QColor(115, 124, 118, 255));
        brush4.setStyle(Qt::NoBrush);
        Gameview->setForegroundBrush(brush4);
        Gameview->setInteractive(true);
        Gameview->setAlignment(Qt::AlignBottom|Qt::AlignJustify);
        Gameview->setTransformationAnchor(QGraphicsView::NoAnchor);
        Gameview->setResizeAnchor(QGraphicsView::AnchorViewCenter);
        Gameview->setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
        Gameview->setRubberBandSelectionMode(Qt::ContainsItemShape);
        Gameview->setOptimizationFlags(QGraphicsView::DontAdjustForAntialiasing);

        Verticallayout->addWidget(Gameview);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 0, 0, 1, 2);

        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 0, 2, 1, 1);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 0, 3, 1, 1);

        Traced = new QCheckBox(centralwidget);
        Traced->setObjectName(QString::fromUtf8("Traced"));

        gridLayout->addWidget(Traced, 0, 4, 1, 1);

        MassSlider = new QSlider(centralwidget);
        MassSlider->setObjectName(QString::fromUtf8("MassSlider"));
        MassSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(MassSlider, 1, 0, 1, 1);

        checkBox = new QCheckBox(centralwidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 1, 1, 1, 1);

        GSlider = new QSlider(centralwidget);
        GSlider->setObjectName(QString::fromUtf8("GSlider"));
        GSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(GSlider, 1, 2, 1, 1);

        TimeSlider = new QSlider(centralwidget);
        TimeSlider->setObjectName(QString::fromUtf8("TimeSlider"));
        TimeSlider->setValue(0);
        TimeSlider->setSliderPosition(0);
        TimeSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(TimeSlider, 1, 3, 1, 1);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 1, 4, 1, 1);

        Refresh = new QPushButton(centralwidget);
        Refresh->setObjectName(QString::fromUtf8("Refresh"));

        gridLayout->addWidget(Refresh, 1, 5, 1, 1);


        Verticallayout->addLayout(gridLayout);

        Verticallayout->setStretch(1, 1);

        verticalLayout->addLayout(Verticallayout);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1443, 20));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuSystems = new QMenu(menuFile);
        menuSystems->setObjectName(QString::fromUtf8("menuSystems"));
        menuCollisions = new QMenu(menuFile);
        menuCollisions->setObjectName(QString::fromUtf8("menuCollisions"));
        menuMusic = new QMenu(menuFile);
        menuMusic->setObjectName(QString::fromUtf8("menuMusic"));
        menuMethod = new QMenu(menuFile);
        menuMethod->setObjectName(QString::fromUtf8("menuMethod"));
        menuBarnes_Hut = new QMenu(menuMethod);
        menuBarnes_Hut->setObjectName(QString::fromUtf8("menuBarnes_Hut"));
        menuBarnes_Hut->setEnabled(true);
        menuRocket = new QMenu(menubar);
        menuRocket->setObjectName(QString::fromUtf8("menuRocket"));
        menuSelect_Program = new QMenu(menuRocket);
        menuSelect_Program->setObjectName(QString::fromUtf8("menuSelect_Program"));
        menuRElativite = new QMenu(menubar);
        menuRElativite->setObjectName(QString::fromUtf8("menuRElativite"));
        menuSystems_2 = new QMenu(menuRElativite);
        menuSystems_2->setObjectName(QString::fromUtf8("menuSystems_2"));
        MainWindow->setMenuBar(menubar);
        QWidget::setTabOrder(TimeSlider, MassSlider);

        menubar->addAction(menuFile->menuAction());
        menubar->addAction(menuRocket->menuAction());
        menubar->addAction(menuRElativite->menuAction());
        menuFile->addAction(menuSystems->menuAction());
        menuFile->addAction(menuCollisions->menuAction());
        menuFile->addAction(menuMusic->menuAction());
        menuFile->addAction(actionLoad_Save);
        menuFile->addAction(menuMethod->menuAction());
        menuSystems->addSeparator();
        menuSystems->addAction(earthmooon);
        menuSystems->addAction(actionBinary);
        menuSystems->addAction(actionBinary_Binary);
        menuSystems->addAction(actionRings);
        menuSystems->addAction(actionInner_Solar_System);
        menuSystems->addAction(actionRandom);
        menuSystems->addAction(actionRandom_Twist);
        menuSystems->addAction(actionSmash);
        menuSystems->addAction(actionPerformance_Test);
        menuCollisions->addAction(Collision);
        menuCollisions->addAction(actionEnable_Debris);
        menuMusic->addAction(actionEnable);
        menuMethod->addAction(menuBarnes_Hut->menuAction());
        menuBarnes_Hut->addAction(Barnes_Hut);
        menuBarnes_Hut->addAction(actionShow_Visualization);
        menuRocket->addAction(Spawn_rocket);
        menuRocket->addAction(menuSelect_Program->menuAction());
        menuSelect_Program->addAction(actionTransfer);
        menuSelect_Program->addAction(actionInter_planetary);
        menuRElativite->addSeparator();
        menuRElativite->addAction(Specialrel);
        menuRElativite->addAction(actionset_Speed_of_Light);
        menuRElativite->addAction(menuSystems_2->menuAction());
        menuSystems_2->addAction(actionPrecession);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Orbi", nullptr));
        earthmooon->setText(QApplication::translate("MainWindow", "Moon", nullptr));
#ifndef QT_NO_TOOLTIP
        earthmooon->setToolTip(QApplication::translate("MainWindow", "Moon", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        earthmooon->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
        actionBinary->setText(QApplication::translate("MainWindow", "Binary", nullptr));
        actionBinary_Binary->setText(QApplication::translate("MainWindow", "Binary-Binary", nullptr));
        actionRings->setText(QApplication::translate("MainWindow", "Rings", nullptr));
        actionInner_Solar_System->setText(QApplication::translate("MainWindow", "Moonception", nullptr));
        actionRandom->setText(QApplication::translate("MainWindow", "Random", nullptr));
        actionRandom_Twist->setText(QApplication::translate("MainWindow", "Random Twist", nullptr));
        Specialrel->setText(QApplication::translate("MainWindow", "Enabled", nullptr));
        Spawn_rocket->setText(QApplication::translate("MainWindow", "Spawn Rocket", nullptr));
        actionset_Speed_of_Light->setText(QApplication::translate("MainWindow", "Set Speed of Light", nullptr));
        Collision->setText(QApplication::translate("MainWindow", "Enable", nullptr));
        actionEnable_Debris->setText(QApplication::translate("MainWindow", "Enable Debris", nullptr));
        actionSmash->setText(QApplication::translate("MainWindow", "Smash", nullptr));
        actionTransfer->setText(QApplication::translate("MainWindow", "Transfer", nullptr));
        actionPrecession->setText(QApplication::translate("MainWindow", "Persession", nullptr));
        actionLoad_Save->setText(QApplication::translate("MainWindow", "Load/Save", nullptr));
        actionEnable->setText(QApplication::translate("MainWindow", "Enable", nullptr));
        actionVolume->setText(QApplication::translate("MainWindow", "Volume", nullptr));
        actionPerformance_Test->setText(QApplication::translate("MainWindow", "Performance Test", nullptr));
        actionShow_Visualization->setText(QApplication::translate("MainWindow", "Show Visualization", nullptr));
        Barnes_Hut->setText(QApplication::translate("MainWindow", "Enable", nullptr));
        actionInter_planetary->setText(QApplication::translate("MainWindow", "Inter planetary", nullptr));
        label->setText(QApplication::translate("MainWindow", "                                   Object mass", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "                                             G", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "                                         Speed", nullptr));
        Traced->setText(QApplication::translate("MainWindow", "Trace", nullptr));
        checkBox->setText(QApplication::translate("MainWindow", "Fixed", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "Clear", nullptr));
        Refresh->setText(QApplication::translate("MainWindow", "Pause/Run", nullptr));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", nullptr));
        menuSystems->setTitle(QApplication::translate("MainWindow", "Systems", nullptr));
        menuCollisions->setTitle(QApplication::translate("MainWindow", "Collisions", nullptr));
        menuMusic->setTitle(QApplication::translate("MainWindow", "Music", nullptr));
        menuMethod->setTitle(QApplication::translate("MainWindow", "Method", nullptr));
        menuBarnes_Hut->setTitle(QApplication::translate("MainWindow", "Barnes-Hut", nullptr));
        menuRocket->setTitle(QApplication::translate("MainWindow", "Rocket", nullptr));
        menuSelect_Program->setTitle(QApplication::translate("MainWindow", "Select Program", nullptr));
        menuRElativite->setTitle(QApplication::translate("MainWindow", "Relativity", nullptr));
        menuSystems_2->setTitle(QApplication::translate("MainWindow", "Systems", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
