/********************************************************************************
** Form generated from reading UI file 'c_slider.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_C_SLIDER_H
#define UI_C_SLIDER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QSlider>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_C_slider
{
public:
    QFormLayout *formLayout;
    QSlider *horizontalSlider;

    void setupUi(QWidget *C_slider)
    {
        if (C_slider->objectName().isEmpty())
            C_slider->setObjectName(QString::fromUtf8("C_slider"));
        C_slider->setWindowModality(Qt::WindowModal);
        C_slider->setEnabled(true);
        C_slider->resize(246, 36);
        C_slider->setFocusPolicy(Qt::ClickFocus);
        C_slider->setContextMenuPolicy(Qt::NoContextMenu);
#ifndef QT_NO_STATUSTIP
        C_slider->setStatusTip(QString::fromUtf8(""));
#endif // QT_NO_STATUSTIP
#ifndef QT_NO_WHATSTHIS
        C_slider->setWhatsThis(QString::fromUtf8(""));
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        C_slider->setAccessibleName(QString::fromUtf8(""));
#endif // QT_NO_ACCESSIBILITY
        formLayout = new QFormLayout(C_slider);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        horizontalSlider = new QSlider(C_slider);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setFocusPolicy(Qt::ClickFocus);
        horizontalSlider->setContextMenuPolicy(Qt::DefaultContextMenu);
        horizontalSlider->setAutoFillBackground(true);
        horizontalSlider->setOrientation(Qt::Horizontal);

        formLayout->setWidget(0, QFormLayout::SpanningRole, horizontalSlider);


        retranslateUi(C_slider);

        QMetaObject::connectSlotsByName(C_slider);
    } // setupUi

    void retranslateUi(QWidget *C_slider)
    {
        C_slider->setWindowTitle(QApplication::translate("C_slider", "Speed of Light :", nullptr));
    } // retranslateUi

};

namespace Ui {
    class C_slider: public Ui_C_slider {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_C_SLIDER_H
