/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.12
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QGraphicsView>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *earthmooon;
    QAction *actionBinary;
    QAction *actionBinary_Binary;
    QAction *actionRings;
    QAction *actionInner_Solar_System;
    QAction *actionRandom;
    QAction *actionRandom_Twist;
    QWidget *centralwidget;
    QGridLayout *gridLayout;
    QLabel *label_2;
    QSlider *TimeSlider;
    QLabel *label;
    QGraphicsView *Gameview;
    QLabel *label_3;
    QPushButton *Refresh;
    QPushButton *pushButton;
    QSlider *MassSlider;
    QCheckBox *checkBox;
    QSlider *horizontalSlider;
    QStatusBar *statusbar;
    QMenuBar *menubar;
    QMenu *menuFile;
    QMenu *menuSystems;
    QMenu *menuCollisions;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1443, 814);
        earthmooon = new QAction(MainWindow);
        earthmooon->setObjectName(QString::fromUtf8("earthmooon"));
        earthmooon->setCheckable(false);
        earthmooon->setShortcutContext(Qt::WidgetShortcut);
        earthmooon->setMenuRole(QAction::ApplicationSpecificRole);
        actionBinary = new QAction(MainWindow);
        actionBinary->setObjectName(QString::fromUtf8("actionBinary"));
        actionBinary_Binary = new QAction(MainWindow);
        actionBinary_Binary->setObjectName(QString::fromUtf8("actionBinary_Binary"));
        actionRings = new QAction(MainWindow);
        actionRings->setObjectName(QString::fromUtf8("actionRings"));
        actionInner_Solar_System = new QAction(MainWindow);
        actionInner_Solar_System->setObjectName(QString::fromUtf8("actionInner_Solar_System"));
        actionRandom = new QAction(MainWindow);
        actionRandom->setObjectName(QString::fromUtf8("actionRandom"));
        actionRandom_Twist = new QAction(MainWindow);
        actionRandom_Twist->setObjectName(QString::fromUtf8("actionRandom_Twist"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(centralwidget);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        label_2 = new QLabel(centralwidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout->addWidget(label_2, 1, 2, 1, 1);

        TimeSlider = new QSlider(centralwidget);
        TimeSlider->setObjectName(QString::fromUtf8("TimeSlider"));
        TimeSlider->setValue(0);
        TimeSlider->setSliderPosition(0);
        TimeSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(TimeSlider, 2, 4, 2, 1);

        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));

        gridLayout->addWidget(label, 1, 0, 1, 1);

        Gameview = new QGraphicsView(centralwidget);
        Gameview->setObjectName(QString::fromUtf8("Gameview"));
        Gameview->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::MinimumExpanding, QSizePolicy::MinimumExpanding);
        sizePolicy1.setHorizontalStretch(1);
        sizePolicy1.setVerticalStretch(1);
        sizePolicy1.setHeightForWidth(Gameview->sizePolicy().hasHeightForWidth());
        Gameview->setSizePolicy(sizePolicy1);
        Gameview->setMinimumSize(QSize(1425, 700));
        Gameview->setMaximumSize(QSize(2440, 1440));
        Gameview->setSizeIncrement(QSize(1, 1));
        Gameview->setBaseSize(QSize(1, 1));
        Gameview->viewport()->setProperty("cursor", QVariant(QCursor(Qt::CrossCursor)));
        Gameview->setMouseTracking(true);
        Gameview->setTabletTracking(false);
        Gameview->setFocusPolicy(Qt::NoFocus);
        Gameview->setContextMenuPolicy(Qt::DefaultContextMenu);
        Gameview->setAcceptDrops(false);
#ifndef QT_NO_WHATSTHIS
        Gameview->setWhatsThis(QString::fromUtf8(""));
#endif // QT_NO_WHATSTHIS
#ifndef QT_NO_ACCESSIBILITY
        Gameview->setAccessibleName(QString::fromUtf8(""));
#endif // QT_NO_ACCESSIBILITY
#ifndef QT_NO_ACCESSIBILITY
        Gameview->setAccessibleDescription(QString::fromUtf8(""));
#endif // QT_NO_ACCESSIBILITY
        Gameview->setLayoutDirection(Qt::LeftToRight);
        Gameview->setAutoFillBackground(true);
        Gameview->setStyleSheet(QString::fromUtf8("background-color: rgb(10, 16, 16);"));
        Gameview->setFrameShape(QFrame::StyledPanel);
        Gameview->setFrameShadow(QFrame::Sunken);
        Gameview->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        Gameview->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
        Gameview->setSizeAdjustPolicy(QAbstractScrollArea::AdjustToContents);
        Gameview->setInteractive(true);
        Gameview->setAlignment(Qt::AlignBottom|Qt::AlignJustify);
        Gameview->setTransformationAnchor(QGraphicsView::NoAnchor);
        Gameview->setResizeAnchor(QGraphicsView::AnchorViewCenter);
        Gameview->setViewportUpdateMode(QGraphicsView::FullViewportUpdate);
        Gameview->setRubberBandSelectionMode(Qt::ContainsItemShape);
        Gameview->setOptimizationFlags(QGraphicsView::DontAdjustForAntialiasing);

        gridLayout->addWidget(Gameview, 0, 0, 1, 5);

        label_3 = new QLabel(centralwidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout->addWidget(label_3, 1, 4, 1, 1);

        Refresh = new QPushButton(centralwidget);
        Refresh->setObjectName(QString::fromUtf8("Refresh"));

        gridLayout->addWidget(Refresh, 3, 3, 1, 1);

        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout->addWidget(pushButton, 1, 3, 2, 1);

        MassSlider = new QSlider(centralwidget);
        MassSlider->setObjectName(QString::fromUtf8("MassSlider"));
        MassSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(MassSlider, 2, 0, 2, 1);

        checkBox = new QCheckBox(centralwidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));

        gridLayout->addWidget(checkBox, 2, 1, 2, 1);

        horizontalSlider = new QSlider(centralwidget);
        horizontalSlider->setObjectName(QString::fromUtf8("horizontalSlider"));
        horizontalSlider->setOrientation(Qt::Horizontal);

        gridLayout->addWidget(horizontalSlider, 2, 2, 2, 1);

        MainWindow->setCentralWidget(centralwidget);
        label->raise();
        Gameview->raise();
        MassSlider->raise();
        TimeSlider->raise();
        label_3->raise();
        pushButton->raise();
        horizontalSlider->raise();
        label_2->raise();
        checkBox->raise();
        Refresh->raise();
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1443, 20));
        menuFile = new QMenu(menubar);
        menuFile->setObjectName(QString::fromUtf8("menuFile"));
        menuSystems = new QMenu(menuFile);
        menuSystems->setObjectName(QString::fromUtf8("menuSystems"));
        menuCollisions = new QMenu(menuFile);
        menuCollisions->setObjectName(QString::fromUtf8("menuCollisions"));
        MainWindow->setMenuBar(menubar);
        QWidget::setTabOrder(horizontalSlider, pushButton);
        QWidget::setTabOrder(pushButton, checkBox);
        QWidget::setTabOrder(checkBox, TimeSlider);
        QWidget::setTabOrder(TimeSlider, MassSlider);

        menubar->addAction(menuFile->menuAction());
        menuFile->addAction(menuSystems->menuAction());
        menuFile->addAction(menuCollisions->menuAction());
        menuSystems->addSeparator();
        menuSystems->addAction(earthmooon);
        menuSystems->addAction(actionBinary);
        menuSystems->addAction(actionBinary_Binary);
        menuSystems->addAction(actionRings);
        menuSystems->addAction(actionInner_Solar_System);
        menuSystems->addAction(actionRandom);
        menuSystems->addAction(actionRandom_Twist);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        earthmooon->setText(QApplication::translate("MainWindow", "Moon", nullptr));
#ifndef QT_NO_TOOLTIP
        earthmooon->setToolTip(QApplication::translate("MainWindow", "Moon", nullptr));
#endif // QT_NO_TOOLTIP
#ifndef QT_NO_STATUSTIP
        earthmooon->setStatusTip(QString());
#endif // QT_NO_STATUSTIP
        actionBinary->setText(QApplication::translate("MainWindow", "Binary", nullptr));
        actionBinary_Binary->setText(QApplication::translate("MainWindow", "Binary-Binary", nullptr));
        actionRings->setText(QApplication::translate("MainWindow", "Rings", nullptr));
        actionInner_Solar_System->setText(QApplication::translate("MainWindow", "Moonception", nullptr));
        actionRandom->setText(QApplication::translate("MainWindow", "Random", nullptr));
        actionRandom_Twist->setText(QApplication::translate("MainWindow", "Random Twist", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "                                             G", nullptr));
        label->setText(QApplication::translate("MainWindow", "                                   Object mass", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "                                         Speed", nullptr));
        Refresh->setText(QApplication::translate("MainWindow", "Pause/Run", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "Clear", nullptr));
        checkBox->setText(QApplication::translate("MainWindow", "Fixed", nullptr));
        menuFile->setTitle(QApplication::translate("MainWindow", "File", nullptr));
        menuSystems->setTitle(QApplication::translate("MainWindow", "Systems", nullptr));
        menuCollisions->setTitle(QApplication::translate("MainWindow", "Collisions", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
