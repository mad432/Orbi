/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.12)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../orbi/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.12. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[24];
    char stringdata0[506];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 29), // "on_Gameview_rubberBandChanged"
QT_MOC_LITERAL(2, 41, 0), // ""
QT_MOC_LITERAL(3, 42, 12), // "viewportRect"
QT_MOC_LITERAL(4, 55, 14), // "fromScenePoint"
QT_MOC_LITERAL(5, 70, 12), // "toScenePoint"
QT_MOC_LITERAL(6, 83, 26), // "on_MassSlider_valueChanged"
QT_MOC_LITERAL(7, 110, 5), // "value"
QT_MOC_LITERAL(8, 116, 26), // "on_TimeSlider_valueChanged"
QT_MOC_LITERAL(9, 143, 8), // "timetick"
QT_MOC_LITERAL(10, 152, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(11, 174, 32), // "on_horizontalSlider_valueChanged"
QT_MOC_LITERAL(12, 207, 19), // "on_checkBox_clicked"
QT_MOC_LITERAL(13, 227, 7), // "checked"
QT_MOC_LITERAL(14, 235, 23), // "on_earthmooon_triggered"
QT_MOC_LITERAL(15, 259, 25), // "on_actionBinary_triggered"
QT_MOC_LITERAL(16, 285, 32), // "on_actionBinary_Binary_triggered"
QT_MOC_LITERAL(17, 318, 24), // "on_actionRings_triggered"
QT_MOC_LITERAL(18, 343, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(19, 367, 23), // "on_pushButton_2_pressed"
QT_MOC_LITERAL(20, 391, 37), // "on_actionInner_Solar_System_t..."
QT_MOC_LITERAL(21, 429, 18), // "on_Refresh_clicked"
QT_MOC_LITERAL(22, 448, 25), // "on_actionRandom_triggered"
QT_MOC_LITERAL(23, 474, 31) // "on_actionRandom_Twist_triggered"

    },
    "MainWindow\0on_Gameview_rubberBandChanged\0"
    "\0viewportRect\0fromScenePoint\0toScenePoint\0"
    "on_MassSlider_valueChanged\0value\0"
    "on_TimeSlider_valueChanged\0timetick\0"
    "on_pushButton_clicked\0"
    "on_horizontalSlider_valueChanged\0"
    "on_checkBox_clicked\0checked\0"
    "on_earthmooon_triggered\0"
    "on_actionBinary_triggered\0"
    "on_actionBinary_Binary_triggered\0"
    "on_actionRings_triggered\0"
    "on_pushButton_2_clicked\0on_pushButton_2_pressed\0"
    "on_actionInner_Solar_System_triggered\0"
    "on_Refresh_clicked\0on_actionRandom_triggered\0"
    "on_actionRandom_Twist_triggered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    3,   99,    2, 0x08 /* Private */,
       6,    1,  106,    2, 0x08 /* Private */,
       8,    1,  109,    2, 0x08 /* Private */,
       9,    0,  112,    2, 0x08 /* Private */,
      10,    0,  113,    2, 0x08 /* Private */,
      11,    1,  114,    2, 0x08 /* Private */,
      12,    1,  117,    2, 0x08 /* Private */,
      14,    0,  120,    2, 0x08 /* Private */,
      15,    0,  121,    2, 0x08 /* Private */,
      16,    0,  122,    2, 0x08 /* Private */,
      17,    0,  123,    2, 0x08 /* Private */,
      18,    0,  124,    2, 0x08 /* Private */,
      19,    0,  125,    2, 0x08 /* Private */,
      20,    0,  126,    2, 0x08 /* Private */,
      21,    0,  127,    2, 0x08 /* Private */,
      22,    0,  128,    2, 0x08 /* Private */,
      23,    0,  129,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::QRect, QMetaType::QPointF, QMetaType::QPointF,    3,    4,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_Gameview_rubberBandChanged((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< const QPointF(*)>(_a[2])),(*reinterpret_cast< const QPointF(*)>(_a[3]))); break;
        case 1: _t->on_MassSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->on_TimeSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->timetick(); break;
        case 4: _t->on_pushButton_clicked(); break;
        case 5: _t->on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_checkBox_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->on_earthmooon_triggered(); break;
        case 8: _t->on_actionBinary_triggered(); break;
        case 9: _t->on_actionBinary_Binary_triggered(); break;
        case 10: _t->on_actionRings_triggered(); break;
        case 11: _t->on_pushButton_2_clicked(); break;
        case 12: _t->on_pushButton_2_pressed(); break;
        case 13: _t->on_actionInner_Solar_System_triggered(); break;
        case 14: _t->on_Refresh_clicked(); break;
        case 15: _t->on_actionRandom_triggered(); break;
        case 16: _t->on_actionRandom_Twist_triggered(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
